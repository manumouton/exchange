package org.manumouton.postfixNotation;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.manumouton.AppTest;

public class PostFixCalculatorTest extends TestCase {

    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public PostFixCalculatorTest(String testName) {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite() {
        return new TestSuite(AppTest.class);
    }

    public void testCalculator() {
        PostFixCalculator postFixCalculator = new PostFixCalculator();

        String expression = "6 8 4 + 3 2 + - *";
        Assert.assertEquals(42.0, postFixCalculator.calculate(expression));

    }

    public void testCalculator1() {
        PostFixCalculator postFixCalculator = new PostFixCalculator();
        String expression2 = "3 4 2 + *";
        Assert.assertEquals(18.0, postFixCalculator.calculate(expression2));

    }

    public void testCalculator2() {
        PostFixCalculator postFixCalculator = new PostFixCalculator();
        String expression3 = "5 4 2 * 3 + + sqrt";
        Assert.assertEquals(4.0, postFixCalculator.calculate(expression3));
    }

    public void testCalculator3() {
        PostFixCalculator postFixCalculator = new PostFixCalculator();
        String expression4 = "3.12 4 + 2 *";
        Assert.assertEquals(14.24, postFixCalculator.calculate(expression4));
    }

    public void testCalculator4() {
        PostFixCalculator postFixCalculator = new PostFixCalculator();
        String expression4 = "1 2 3 4 5 6 7 8 9 10 avg";
        Assert.assertEquals(5.5, postFixCalculator.calculate(expression4));
    }

}
