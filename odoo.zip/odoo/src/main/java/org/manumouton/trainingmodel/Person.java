package org.manumouton.trainingmodel;

public class Person {

    public Person(String name, Employer employer) {
        this.name = name;
        this.employer = employer;
    }

    private String name;
    private Employer employer;
}
