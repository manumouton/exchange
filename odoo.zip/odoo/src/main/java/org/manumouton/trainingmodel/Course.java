package org.manumouton.trainingmodel;

public class Course {

    public Course(String name, String type, int duration, Person responsible) {
        this.name = name;
        this.type = type;
        this.duration = duration;
        this.responsible = responsible;
    }

    private String name;
    //Should be replaced by constant or enum in the future
    private String type;
    //duration in days
    private int duration;
    //Only one person could be responsible of a given course
    private Person responsible;
}
