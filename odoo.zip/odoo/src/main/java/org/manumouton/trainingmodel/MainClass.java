package org.manumouton.trainingmodel;

public class MainClass {

    public static void main(String[] args){

        //Employers

        //Attendees

        //Course trainers

        //Course responsibles

        //Courses

       // Course javaCourse = new Course("Introduction to Java", "technical", 5, )


        //Courses sessions

    }
}
