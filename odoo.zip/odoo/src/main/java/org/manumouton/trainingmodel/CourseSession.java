package org.manumouton.trainingmodel;

import java.util.Date;
import java.util.List;

public class CourseSession {

    public CourseSession(Course course, List<Person> attendees, Person trainer, int weekNumber) {
        this.course = course;
        this.attendees = attendees;
        this.trainer = trainer;
        this.weekNumber = weekNumber;
    }

    private Course course;
    private List<Person> attendees;
    private Person trainer;

    private int weekNumber;

    //private Date startDate;
    //private Date endDate;
}
