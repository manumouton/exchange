package org.manumouton.postfixNotation;

public class PostfixMain {

    public static void main(String[] args){



    }
}
