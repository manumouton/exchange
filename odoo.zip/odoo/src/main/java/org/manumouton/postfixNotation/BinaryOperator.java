package org.manumouton.postfixNotation;

import java.util.Arrays;
import java.util.List;

public class BinaryOperator {

    private static final List<String> BIN_OPERATORS = Arrays.asList("+", "-", "*", "/");

    public static boolean isBinaryOperator(String expr){
        return BIN_OPERATORS.contains(expr);
    }

    public static double resolve(String operator, double a, double b){
        if(operator.equals("+")){
            return a + b;
        }
        else if(operator.equals("-")){
            return b - a;
        }
        else if(operator.equals("*")){
            return a * b;
        }
        else if(operator.equals("/")){
            return b / a;
        }
        else {
            throw new UnsupportedOperationException("Not supported!" + operator);
        }
    }
}
