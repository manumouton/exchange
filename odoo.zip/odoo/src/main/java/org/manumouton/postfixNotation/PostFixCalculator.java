package org.manumouton.postfixNotation;

import java.util.Stack;

public class PostFixCalculator {

    private final String SUPPORTED_ELEMENTS = "";

    public double calculate(String expression){
        if(validateExpression(expression)){
            String[] splittedExpression = expression.split(" ");

            return calculateExpression(splittedExpression);
        }
        return 0;
    }

    //Method used to validate the content of an expression
    private boolean validateExpression(String expression){
        return true;
        //return expression.matches(SUPPORTED_ELEMENTS);
    }

    private double calculateExpression(String[] expression){

        Stack<Double> digitStack = new Stack<>();
        System.out.println("Expression to calculate :" + expression);

        for(String element : expression){

            //If this is a number, put it in the stack
            if(Number.isNumber(element)){
                digitStack.push(Number.parse(element));
            }
            //Operators or space
            else if(BinaryOperator.isBinaryOperator(element)) {
                double a = digitStack.pop();
                double b = digitStack.pop();

                digitStack.push(BinaryOperator.resolve(element, a, b));
            }
            else if(UnaryOperator.isUnaryOperator(element)) {
                double a = digitStack.pop();

                digitStack.push(UnaryOperator.resolve(element, a));
            }
            else if(AverageOperator.isAverageOperator(element)){
                double avg = AverageOperator.resolve(element, digitStack);
                digitStack.empty();
                digitStack.push(avg);
            }
            else{

            }
        }

        return digitStack.pop();
    }

}
