package org.manumouton.postfixNotation;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class AverageOperator {

    private static final List<String> AVG_OPERATORS = Arrays.asList("avg");

    public static boolean isAverageOperator(String expr){
        return AVG_OPERATORS.contains(expr);
    }

    public static double resolve(String operator, Stack<Double> digitStack ){
        if(operator.equals("avg")){
            return calculateAverage(digitStack);
        }
        else {
            throw new UnsupportedOperationException("Not supported!" + operator);
        }
    }

    private static double calculateAverage(Stack<Double> digitStack) {
        int numberOfElement = digitStack.size();
        double sum = 0.0;
        for(Double d : digitStack){
            sum += d;
        }

        return sum / numberOfElement;

    }
}
