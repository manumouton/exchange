package org.manumouton.postfixNotation;

public class Number {

    public static boolean isNumber(String numberExpr){
        try{
            Double.parseDouble(numberExpr);
            return true;
        }
        catch(NumberFormatException e){
            return false;
        }
    }

    public static Double parse(String expr){
        try {
            return Double.parseDouble(expr);
        }
        catch (NumberFormatException e){
            System.out.println("This expression is not a number!");
            return 0.0;
        }
    }
}
