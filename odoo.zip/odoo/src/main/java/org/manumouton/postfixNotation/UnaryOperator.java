package org.manumouton.postfixNotation;

import java.util.Arrays;
import java.util.List;

public class UnaryOperator {

    private static final List<String> UN_OPERATORS = Arrays.asList("sqrt");

    public static boolean isUnaryOperator(String expr){
        return UN_OPERATORS.contains(expr);
    }

    public static double resolve(String operator, double a){
        if(operator.equals("sqrt")){
            return Math.sqrt(a);
        }
        else {
            throw new UnsupportedOperationException("Not supported!" + operator);
        }
    }
}
