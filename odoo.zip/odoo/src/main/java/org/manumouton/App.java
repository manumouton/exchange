package org.manumouton;

import java.util.Arrays;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Arrays.stream(args).forEach(arg -> System.out.println("This is my arg"));
    }
}
